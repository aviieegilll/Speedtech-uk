import React from 'react';
import useScrollReveal from '@/hooks/useScrollReveal';
import useAnimatedCounter from '@/hooks/useAnimatedCounter';
import {
  Monitor, Satellite, Lock, Radio, BarChart3, Globe, Wifi, Database
} from 'lucide-react';

const TECH_FEATURES = [
  { icon: Monitor, title: 'Day Book Pro', desc: 'Transport management platform' },
  { icon: Database, title: 'API Integrations', desc: 'Customer system connectivity' },
  { icon: Globe, title: 'Online Booking', desc: 'Digital booking portal' },
  { icon: Wifi, title: 'Real-Time Notifications', desc: 'Live shipment updates' },
  { icon: Satellite, title: 'GPS Tracking', desc: 'Quartix platform' },
  { icon: Radio, title: 'Geofencing', desc: 'Zone-based monitoring' },
  { icon: Lock, title: 'Electronic Seals', desc: 'Tamper-proof security' },
  { icon: BarChart3, title: 'EDI Systems', desc: 'Electronic data interchange' },
];

const STATS = [
  { value: 99.9, suffix: '%', label: 'On-Time Delivery' },
  { value: 24, suffix: '/7', label: 'Operations' },
  { value: 138, suffix: '+', label: 'Fleet Vehicles' },
  { value: 20, suffix: '+', label: 'Years of Excellence' },
];

export default function TechnologySection() {
  const [ref, isVisible] = useScrollReveal();

  return (
    <section id="technology" className="py-24 lg:py-32 bg-midnight relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-20 w-96 h-96 rounded-full bg-velocity blur-[100px]" />
        <div className="absolute bottom-20 right-20 w-96 h-96 rounded-full bg-blue-500 blur-[100px]" />
      </div>

      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="flex items-center gap-3 mb-6 justify-center">
            <div className="w-8 h-px bg-velocity" />
            <span className="font-mono text-xs tracking-[0.15em] uppercase text-velocity font-semibold">
              Technology & Tracking
            </span>
            <div className="w-8 h-px bg-velocity" />
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-white tracking-tight mb-4">
            Precision <span className="text-velocity">Control Room</span>
          </h2>
          <p className="text-lg text-white/50">
            Complete visibility across every shipment with enterprise-grade 
            tracking, monitoring, and management systems.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {STATS.map((stat, i) => (
            <StatCard key={stat.label} stat={stat} isVisible={isVisible} delay={i * 100} />
          ))}
        </div>

        {/* Tech Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {TECH_FEATURES.map((tech, i) => (
            <div
              key={tech.title}
              className={`glass-dark rounded-xl p-5 group hover:bg-white/10 transition-all duration-500 ${
                isVisible ? 'animate-fade-up' : 'opacity-0'
              }`}
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <tech.icon className="w-6 h-6 text-velocity mb-3 group-hover:scale-110 transition-transform" />
              <h3 className="text-sm font-bold text-white mb-1">{tech.title}</h3>
              <p className="text-xs text-white/40">{tech.desc}</p>
            </div>
          ))}
        </div>

        {/* ADDSECURE callout */}
        <div className="mt-12 glass-dark rounded-2xl p-8 flex flex-col lg:flex-row items-center gap-8 text-center lg:text-left">
          <div className="w-16 h-16 rounded-2xl bg-velocity/20 flex items-center justify-center shrink-0">
            <Satellite className="w-8 h-8 text-velocity" />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-bold text-white mb-2">
              ADDSECURE Remote Temperature Monitoring
            </h3>
            <p className="text-white/50">
              Real-time temperature monitoring for pharmaceutical and healthcare logistics, 
              ensuring GDP compliance and cold-chain integrity across every journey.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function StatCard({ stat, isVisible, delay }) {
  const count = useAnimatedCounter(stat.value, isVisible);
  return (
    <div
      className={`glass-dark rounded-2xl p-6 text-center ${
        isVisible ? 'animate-fade-up' : 'opacity-0'
      }`}
      style={{ animationDelay: `${delay}ms` }}
    >
      <p className="text-4xl lg:text-5xl font-bold text-white mb-2">
        {count}{stat.suffix}
      </p>
      <p className="text-sm text-white/40 font-mono uppercase tracking-wider">
        {stat.label}
      </p>
    </div>
  );
}