import React from 'react';
import useScrollReveal from '@/hooks/useScrollReveal';
import SectionLabel from './SectionLabel';
import {
  CheckCircle2, Truck, Satellite, Users, Monitor, Lock, Shield, Globe
} from 'lucide-react';

const REASONS = [
  { icon: CheckCircle2, title: 'High Quality Standards', desc: 'ISO 9001:2015 certified quality management across all operations' },
  { icon: Truck, title: 'Modern Fleet', desc: '138+ specialist vehicles with latest technology and safety systems' },
  { icon: Satellite, title: 'Comprehensive Tracking', desc: 'Real-time GPS, geofencing, and live shipment visibility' },
  { icon: Users, title: 'Experienced Team', desc: '20+ years of specialist logistics expertise and dedication' },
  { icon: Monitor, title: 'Customer Online Booking', desc: 'Digital portal for seamless booking and shipment management' },
  { icon: Lock, title: 'Electronic Security Seals', desc: 'Tamper-proof seal systems for maximum cargo security' },
  { icon: Shield, title: 'Aviation Security Expertise', desc: 'CAA Regulated Agent with full aviation compliance' },
  { icon: Globe, title: 'Nationwide Support', desc: 'UK-wide coverage from Heathrow and Manchester hubs' },
];

export default function WhyChooseSection() {
  const [ref, isVisible] = useScrollReveal();

  return (
    <section className="py-24 lg:py-32 bg-white">
      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <div className="text-center max-w-3xl mx-auto mb-16">
          <SectionLabel label="Why Choose Us" />
          <h2 className="text-4xl lg:text-5xl font-bold text-midnight tracking-tight mb-4">
            Customers Enjoying The
            <br />
            <span className="text-velocity">Speed-Tech UK Experience</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {REASONS.map((reason, i) => (
            <div
              key={reason.title}
              className={`text-center p-6 rounded-2xl group hover:bg-cloud-deck transition-all duration-500 ${
                isVisible ? 'animate-fade-up' : 'opacity-0'
              }`}
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <div className="w-14 h-14 rounded-2xl bg-velocity/8 flex items-center justify-center mx-auto mb-4 group-hover:bg-velocity group-hover:shadow-lg group-hover:shadow-velocity/20 transition-all duration-500">
                <reason.icon className="w-7 h-7 text-velocity group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-bold text-midnight text-sm mb-2">{reason.title}</h3>
              <p className="text-xs text-midnight/40 leading-relaxed">{reason.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}