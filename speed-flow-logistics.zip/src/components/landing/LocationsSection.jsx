import React, { useState } from 'react';
import useScrollReveal from '@/hooks/useScrollReveal';
import SectionLabel from './SectionLabel';
import { MapPin, Phone, Clock, ChevronRight } from 'lucide-react';

const LOCATIONS = [
  {
    name: 'Heathrow Cargo',
    subtitle: 'Horse Shoe Sheds',
    address: 'Heathrow Airport, London',
    status: 'ACTIVE 24/7',
    type: 'Primary Hub',
  },
  {
    name: 'Heathrow Ops Centre',
    subtitle: 'Stanwell',
    address: 'Mentone Farm, Crane Road, Bedfont Road, Stanwell TW19 7LY',
    status: 'ACTIVE 24/7',
    type: 'Operations Centre',
  },
  {
    name: 'Manchester Airport',
    subtitle: 'World Freight Terminal',
    address: 'Unit 10, Bldg 301, World Freight Terminal, Manchester Airport, M90 5UX',
    status: 'ACTIVE 24/7',
    type: 'Northern Hub',
  },
  {
    name: 'Heathrow Administration',
    subtitle: 'Colnbrook',
    address: 'Unit A1, Skyway 14, Calder Way, Colnbrook, Berkshire SL3 0BQ',
    status: 'ACTIVE',
    type: 'Administration',
  },
];

export default function LocationsSection() {
  const [ref, isVisible] = useScrollReveal();
  const [activeLocation, setActiveLocation] = useState(0);

  return (
    <section id="locations" className="py-24 lg:py-32 bg-white">
      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <div className="grid lg:grid-cols-2 gap-16">
          <div>
            <SectionLabel label="Our Locations" />
            <h2 className="text-4xl lg:text-5xl font-bold text-midnight tracking-tight mb-4">
              Strategic <span className="text-velocity">UK Coverage</span>
            </h2>
            <p className="text-lg text-midnight/50 leading-relaxed mb-10">
              Operating from strategic hubs across the United Kingdom, providing 
              seamless connectivity between Heathrow, Manchester, and nationwide destinations.
            </p>

            <div className="space-y-3">
              {LOCATIONS.map((loc, i) => (
                <div
                  key={loc.name}
                  onClick={() => setActiveLocation(i)}
                  className={`rounded-xl p-5 cursor-pointer transition-all duration-500 border ${
                    activeLocation === i
                      ? 'bg-midnight text-white border-midnight shadow-xl shadow-midnight/20'
                      : 'bg-white text-midnight border-midnight/10 hover:border-velocity/20'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <MapPin className={`w-5 h-5 ${activeLocation === i ? 'text-velocity' : 'text-velocity/60'}`} />
                      <div>
                        <h3 className="font-bold text-base">{loc.name}</h3>
                        <p className={`text-xs ${activeLocation === i ? 'text-white/50' : 'text-midnight/40'}`}>
                          {loc.subtitle}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                      <span className="font-mono text-[10px] tracking-wider text-green-400">
                        {loc.status}
                      </span>
                    </div>
                  </div>
                  {activeLocation === i && (
                    <p className="text-sm text-white/60 ml-8 mt-2">{loc.address}</p>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Map visual placeholder */}
          <div className="relative">
            <div className="bg-midnight/5 rounded-2xl h-full min-h-[400px] relative overflow-hidden">
              {/* Stylized map */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative w-full h-full p-8">
                  {/* UK outline shape — simple stylized */}
                  <svg viewBox="0 0 400 600" className="w-full h-full opacity-10">
                    <path
                      d="M200 50 L260 100 L280 180 L320 200 L350 280 L340 350 L300 380 L280 450 L250 500 L200 550 L150 500 L120 450 L100 380 L60 350 L50 280 L80 200 L120 180 L140 100 Z"
                      fill="none"
                      stroke="#0A1128"
                      strokeWidth="2"
                    />
                  </svg>

                  {/* Heathrow node */}
                  <div className="absolute bottom-[30%] left-[45%] group cursor-pointer">
                    <div className="w-4 h-4 bg-velocity rounded-full relative z-10">
                      <div className="absolute inset-0 bg-velocity rounded-full animate-pulse-ring" />
                    </div>
                    <div className="absolute -top-8 left-6 whitespace-nowrap">
                      <span className="text-xs font-bold text-midnight bg-white px-2 py-1 rounded shadow-sm">
                        HEATHROW
                      </span>
                    </div>
                  </div>

                  {/* Manchester node */}
                  <div className="absolute top-[35%] left-[40%] group cursor-pointer">
                    <div className="w-4 h-4 bg-velocity rounded-full relative z-10">
                      <div className="absolute inset-0 bg-velocity rounded-full animate-pulse-ring" />
                    </div>
                    <div className="absolute -top-8 left-6 whitespace-nowrap">
                      <span className="text-xs font-bold text-midnight bg-white px-2 py-1 rounded shadow-sm">
                        MANCHESTER
                      </span>
                    </div>
                  </div>

                  {/* Connection line */}
                  <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 100 100" preserveAspectRatio="none">
                    <line
                      x1="45" y1="70" x2="40" y2="35"
                      stroke="#D90429"
                      strokeWidth="0.3"
                      strokeDasharray="2 2"
                      opacity="0.5"
                    />
                  </svg>
                </div>
              </div>

              {/* Info card */}
              <div className="absolute bottom-6 left-6 right-6">
                <div className="glass rounded-xl p-5">
                  <div className="flex items-center gap-3 mb-3">
                    <MapPin className="w-5 h-5 text-velocity" />
                    <h3 className="font-bold text-midnight">{LOCATIONS[activeLocation].name}</h3>
                  </div>
                  <p className="text-sm text-midnight/60 mb-3">{LOCATIONS[activeLocation].address}</p>
                  <div className="flex items-center gap-4 text-xs text-midnight/40">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" /> 24/7 Operations
                    </span>
                    <span className="flex items-center gap-1">
                      <Phone className="w-3 h-3" /> 01753 688059
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}