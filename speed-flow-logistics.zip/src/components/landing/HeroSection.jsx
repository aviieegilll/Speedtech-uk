import React from 'react';
import { ArrowRight, MapPin, Clock, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

export default function HeroSection({ heroImage }) {
  return (
    <section id="hero" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Speed-Tech UK logistics fleet at Heathrow"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-midnight/90 via-midnight/70 to-midnight/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-midnight/60 via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-32 pb-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div className="flex items-center gap-3 mb-8">
                <div className="w-10 h-px bg-velocity" />
                <span className="font-mono text-xs tracking-[0.2em] uppercase text-velocity font-semibold">
                  Est. 2004 — Heathrow, United Kingdom
                </span>
              </div>

              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white leading-[1.05] tracking-tight mb-6">
                THE SPEED
                <br />
                <span className="text-velocity">OF TRUST.</span>
              </h1>

              <p className="text-lg text-white/70 max-w-lg leading-relaxed mb-10">
                Your trusted air freight haulage partner. Specialist Heathrow-based 
                logistics delivering nationwide precision with 24/7 operations, 
                aviation security compliance, and cutting-edge tracking technology.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <a href="#contact">
                  <Button className="bg-velocity hover:bg-velocity/90 text-white rounded-full px-8 py-6 text-base gap-2 group w-full sm:w-auto">
                    Request a Quote
                    <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
                  </Button>
                </a>
                <a href="#services">
                  <Button
                    variant="outline"
                    className="border-white/20 text-white hover:bg-white/10 hover:text-white rounded-full px-8 py-6 text-base w-full sm:w-auto"
                  >
                    Explore Services
                  </Button>
                </a>
              </div>
            </motion.div>
          </div>

          {/* Floating Status Card */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="hidden lg:block"
          >
            <div className="glass-dark rounded-2xl p-8 max-w-sm ml-auto">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="font-mono text-xs text-green-400 tracking-wider uppercase">
                  Operations Active
                </span>
              </div>

              <div className="space-y-5">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center">
                    <MapPin className="w-5 h-5 text-velocity" />
                  </div>
                  <div>
                    <p className="text-white/50 text-xs font-mono uppercase tracking-wider">Primary Hub</p>
                    <p className="text-white font-semibold">London Heathrow</p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center">
                    <Clock className="w-5 h-5 text-velocity" />
                  </div>
                  <div>
                    <p className="text-white/50 text-xs font-mono uppercase tracking-wider">Operations</p>
                    <p className="text-white font-semibold">24/7 Nationwide</p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center">
                    <Shield className="w-5 h-5 text-velocity" />
                  </div>
                  <div>
                    <p className="text-white/50 text-xs font-mono uppercase tracking-wider">Security</p>
                    <p className="text-white font-semibold">CAA Regulated Agent</p>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-white/10">
                <p className="text-white/40 text-xs font-mono">
                  GB/RA/00972-01 • ISO 9001:2015
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent" />
    </section>
  );
}