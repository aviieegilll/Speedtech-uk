import React, { useState } from 'react';
import useScrollReveal from '@/hooks/useScrollReveal';
import SectionLabel from './SectionLabel';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Phone, Mail, Clock, MapPin, Send, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

export default function ContactSection() {
  const [ref, isVisible] = useScrollReveal();
  const [form, setForm] = useState({ name: '', email: '', phone: '', company: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    toast.success('Your message has been sent. We will get back to you shortly.');
    setForm({ name: '', email: '', phone: '', company: '', message: '' });
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <section id="contact" className="py-24 lg:py-32 bg-cloud-deck">
      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <div className="grid lg:grid-cols-2 gap-16">
          <div>
            <SectionLabel label="Get In Touch" />
            <h2 className="text-4xl lg:text-5xl font-bold text-midnight tracking-tight mb-6">
              Let's Move Your
              <br />
              <span className="text-velocity">Freight Forward</span>
            </h2>
            <p className="text-lg text-midnight/50 leading-relaxed mb-10">
              Whether you need same-day delivery, specialist cargo handling, or a long-term 
              logistics partnership, our team is ready to help 24/7.
            </p>

            <div className="space-y-6">
              <a href="tel:01753688059" className="flex items-center gap-4 group">
                <div className="w-12 h-12 rounded-xl bg-velocity/10 flex items-center justify-center group-hover:bg-velocity transition-all">
                  <Phone className="w-5 h-5 text-velocity group-hover:text-white transition-colors" />
                </div>
                <div>
                  <p className="text-xs text-midnight/40 font-mono uppercase tracking-wider">Phone</p>
                  <p className="text-lg font-bold text-midnight">01753 688059</p>
                </div>
              </a>
              <a href="mailto:ops@speedtechuk.com" className="flex items-center gap-4 group">
                <div className="w-12 h-12 rounded-xl bg-velocity/10 flex items-center justify-center group-hover:bg-velocity transition-all">
                  <Mail className="w-5 h-5 text-velocity group-hover:text-white transition-colors" />
                </div>
                <div>
                  <p className="text-xs text-midnight/40 font-mono uppercase tracking-wider">Email</p>
                  <p className="text-lg font-bold text-midnight">ops@speedtechuk.com</p>
                </div>
              </a>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-velocity/10 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-velocity" />
                </div>
                <div>
                  <p className="text-xs text-midnight/40 font-mono uppercase tracking-wider">Support</p>
                  <p className="text-lg font-bold text-midnight">24/7 Customer Support</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-velocity/10 flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-velocity" />
                </div>
                <div>
                  <p className="text-xs text-midnight/40 font-mono uppercase tracking-wider">Head Office</p>
                  <p className="text-sm text-midnight/60">Skyway 14, Calder Way, Colnbrook, Berkshire SL3 0BQ</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white rounded-2xl p-8 lg:p-10 shadow-xl shadow-midnight/5">
            <h3 className="text-xl font-bold text-midnight mb-6">Request a Quote</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <Input
                  placeholder="Full Name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  required
                  className="bg-cloud-deck border-0 h-12 rounded-xl"
                />
                <Input
                  placeholder="Email Address"
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  required
                  className="bg-cloud-deck border-0 h-12 rounded-xl"
                />
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <Input
                  placeholder="Phone Number"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="bg-cloud-deck border-0 h-12 rounded-xl"
                />
                <Input
                  placeholder="Company"
                  value={form.company}
                  onChange={(e) => setForm({ ...form, company: e.target.value })}
                  className="bg-cloud-deck border-0 h-12 rounded-xl"
                />
              </div>
              <Textarea
                placeholder="Tell us about your logistics requirements..."
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                required
                rows={5}
                className="bg-cloud-deck border-0 rounded-xl resize-none"
              />
              <Button
                type="submit"
                className="w-full bg-velocity hover:bg-velocity/90 text-white rounded-xl h-12 text-base gap-2 group"
                disabled={submitted}
              >
                {submitted ? (
                  <>
                    <CheckCircle2 className="w-5 h-5" /> Message Sent
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5 transition-transform group-hover:translate-x-1" />
                    Send Message
                  </>
                )}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}