import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { X, RotateCcw, ZoomIn, ZoomOut, Info } from 'lucide-react';

// Hotspot definitions — 3D positions + info panels
const HOTSPOTS = [
  {
    id: 'cabin',
    label: 'Aerodynamic Cabin',
    position: new THREE.Vector3(-1.6, 0.9, 0),
    color: '#D90429',
    detail: {
      title: 'Temperature-Controlled Cabin',
      specs: [
        'ADDSECURE remote monitoring',
        'GDP-compliant cold-chain',
        'Real-time temp alerts',
        'Dual-zone climate control',
      ],
    },
  },
  {
    id: 'rollerbed',
    label: 'Rollerbed System',
    position: new THREE.Vector3(0.6, 0.2, 0.85),
    color: '#D90429',
    detail: {
      title: 'Q6 / Q7 Rollerbed System',
      specs: [
        'ULD-compatible roller tracks',
        'Hydraroll powered loading',
        'Air-ride suspension coupling',
        'Electronic load sensing',
      ],
    },
  },
  {
    id: 'exhaust',
    label: 'Euro 6 Powertrain',
    position: new THREE.Vector3(-1.2, 1.3, -0.55),
    color: '#D90429',
    detail: {
      title: 'Euro 6 Compliant Engine',
      specs: [
        'Volvo / Scania D13 engine',
        'SCR + EGR emissions system',
        'I-Shift automated gearbox',
        'Predictive cruise control',
      ],
    },
  },
  {
    id: 'seal',
    label: 'Electronic Seals',
    position: new THREE.Vector3(1.8, 0.05, 0),
    color: '#D90429',
    detail: {
      title: 'Electronic Security Seals',
      specs: [
        'Tamper-evident bolt seals',
        'CAA aviation-grade security',
        'GPS geofence triggers',
        'Real-time breach alerts',
      ],
    },
  },
  {
    id: 'gps',
    label: 'Quartix GPS Unit',
    position: new THREE.Vector3(-1.5, 1.5, 0.3),
    color: '#D90429',
    detail: {
      title: 'Quartix GPS Tracking',
      specs: [
        'Live vehicle tracking',
        'Route optimisation',
        'Geofencing alerts',
        'Driver behaviour analytics',
      ],
    },
  },
];

// Build a stylised low-poly truck in Three.js
function buildTruck(scene) {
  const group = new THREE.Group();

  const midnight = 0x0a1128;
  const red = 0xd90429;
  const chrome = 0xc0c8d8;
  const glass = 0x88aacc;
  const dark = 0x1a2444;
  const tyre = 0x111111;
  const lightCol = 0xffe680;

  const mat = (color, opts = {}) =>
    new THREE.MeshStandardMaterial({ color, ...opts });

  // === TRAILER ===
  const trailerBody = new THREE.Mesh(
    new THREE.BoxGeometry(3.8, 1.1, 1.7),
    mat(midnight)
  );
  trailerBody.position.set(1.2, 0.35, 0);
  group.add(trailerBody);

  // Trailer top stripe
  const stripe = new THREE.Mesh(
    new THREE.BoxGeometry(3.82, 0.08, 1.72),
    mat(red)
  );
  stripe.position.set(1.2, 0.92, 0);
  group.add(stripe);

  // Trailer rear doors
  const rearDoor = new THREE.Mesh(
    new THREE.BoxGeometry(0.05, 1.1, 1.7),
    mat(dark)
  );
  rearDoor.position.set(3.12, 0.35, 0);
  group.add(rearDoor);

  // Rear lights
  [-0.7, 0.7].forEach((z) => {
    const rLight = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.18, 0.18), mat(red));
    rLight.position.set(3.14, 0.5, z);
    group.add(rLight);
  });

  // Rollerbed floor detail
  for (let i = 0; i < 8; i++) {
    const roller = new THREE.Mesh(
      new THREE.CylinderGeometry(0.04, 0.04, 1.65, 8),
      mat(chrome)
    );
    roller.rotation.z = Math.PI / 2;
    roller.position.set(-0.3 + i * 0.5, -0.2, 0);
    group.add(roller);
  }

  // === CHASSIS ===
  const chassis = new THREE.Mesh(
    new THREE.BoxGeometry(5.2, 0.12, 0.5),
    mat(dark)
  );
  chassis.position.set(0, -0.2, 0);
  group.add(chassis);

  // === CAB ===
  // Cab body
  const cab = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.1, 1.7), mat(midnight));
  cab.position.set(-1.4, 0.45, 0);
  group.add(cab);

  // Cab roof fairing (rounded top)
  const roofFairing = new THREE.Mesh(
    new THREE.BoxGeometry(1.38, 0.35, 1.68),
    mat(dark)
  );
  roofFairing.position.set(-1.4, 1.08, 0);
  group.add(roofFairing);

  // Cab front face
  const cabFront = new THREE.Mesh(
    new THREE.BoxGeometry(0.08, 1.1, 1.7),
    mat(dark)
  );
  cabFront.position.set(-2.1, 0.45, 0);
  group.add(cabFront);

  // Windscreen
  const windscreen = new THREE.Mesh(
    new THREE.BoxGeometry(0.04, 0.65, 1.3),
    mat(glass, { transparent: true, opacity: 0.55 })
  );
  windscreen.position.set(-2.09, 0.7, 0);
  group.add(windscreen);

  // Headlights
  [-0.6, 0.6].forEach((z) => {
    const hl = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.22, 0.3), mat(lightCol));
    hl.position.set(-2.11, 0.28, z);
    group.add(hl);
    const halo = new THREE.PointLight(lightCol, 0.4, 1.5);
    halo.position.set(-2.2, 0.28, z);
    group.add(halo);
  });

  // Grille
  const grille = new THREE.Mesh(
    new THREE.BoxGeometry(0.06, 0.35, 1.1),
    mat(chrome, { roughness: 0.3, metalness: 0.9 })
  );
  grille.position.set(-2.11, 0.08, 0);
  group.add(grille);

  // Grille bars
  for (let i = 0; i < 5; i++) {
    const bar = new THREE.Mesh(
      new THREE.BoxGeometry(0.07, 0.04, 1.1),
      mat(chrome, { metalness: 0.9, roughness: 0.2 })
    );
    bar.position.set(-2.11, -0.06 + i * 0.1, 0);
    group.add(bar);
  }

  // Bumper
  const bumper = new THREE.Mesh(
    new THREE.BoxGeometry(0.25, 0.14, 1.72),
    mat(chrome, { metalness: 0.8, roughness: 0.3 })
  );
  bumper.position.set(-2.15, -0.15, 0);
  group.add(bumper);

  // Cab side mirrors
  [-0.87, 0.87].forEach((z) => {
    const mirror = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.12, 0.06), mat(dark));
    mirror.position.set(-1.9, 0.95, z);
    group.add(mirror);
  });

  // Exhaust stack
  const exhaust = new THREE.Mesh(
    new THREE.CylinderGeometry(0.04, 0.04, 0.8, 8),
    mat(chrome, { metalness: 0.9, roughness: 0.2 })
  );
  exhaust.position.set(-1.3, 1.3, -0.6);
  group.add(exhaust);

  // === COUPLING ===
  const coupling = new THREE.Mesh(
    new THREE.BoxGeometry(0.35, 0.1, 0.35),
    mat(chrome, { metalness: 0.9, roughness: 0.2 })
  );
  coupling.position.set(-0.55, -0.15, 0);
  group.add(coupling);

  // === WHEELS ===
  const wheelPositions = [
    [-1.7, -0.28, 0.85], [-1.7, -0.28, -0.85],
    [-0.95, -0.28, 0.85], [-0.95, -0.28, -0.85],
    [0.4, -0.28, 0.88], [0.4, -0.28, -0.88],
    [1.8, -0.28, 0.88], [1.8, -0.28, -0.88],
    [2.6, -0.28, 0.88], [2.6, -0.28, -0.88],
  ];

  wheelPositions.forEach(([x, y, z]) => {
    const wheel = new THREE.Mesh(
      new THREE.CylinderGeometry(0.28, 0.28, 0.22, 16),
      mat(tyre, { roughness: 0.9 })
    );
    wheel.rotation.x = Math.PI / 2;
    wheel.position.set(x, y, z);
    group.add(wheel);

    const rim = new THREE.Mesh(
      new THREE.CylinderGeometry(0.16, 0.16, 0.24, 12),
      mat(chrome, { metalness: 0.9, roughness: 0.2 })
    );
    rim.rotation.x = Math.PI / 2;
    rim.position.set(x, y, z);
    group.add(rim);
  });

  // === GROUND SHADOW PLANE ===
  const shadowPlane = new THREE.Mesh(
    new THREE.PlaneGeometry(8, 4),
    new THREE.MeshStandardMaterial({ color: 0x0a1128, transparent: true, opacity: 0.12 })
  );
  shadowPlane.rotation.x = -Math.PI / 2;
  shadowPlane.position.y = -0.57;
  group.add(shadowPlane);

  scene.add(group);
  return group;
}

// Build hotspot mesh markers
function buildHotspotMeshes(scene, hotspots) {
  return hotspots.map((hs) => {
    const geo = new THREE.SphereGeometry(0.07, 16, 16);
    const mat = new THREE.MeshStandardMaterial({
      color: 0xd90429,
      emissive: 0xd90429,
      emissiveIntensity: 0.8,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.copy(hs.position);
    mesh.userData.hotspotId = hs.id;
    scene.add(mesh);

    // Pulsing ring
    const ringGeo = new THREE.RingGeometry(0.09, 0.13, 24);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0xd90429,
      transparent: true,
      opacity: 0.5,
      side: THREE.DoubleSide,
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.copy(hs.position);
    ring.userData.isRing = true;
    scene.add(ring);

    return { mesh, ring, hs };
  });
}

export default function TruckViewer3D() {
  const mountRef = useRef(null);
  const sceneRef = useRef(null);
  const rendererRef = useRef(null);
  const cameraRef = useRef(null);
  const truckRef = useRef(null);
  const hotspotMeshesRef = useRef([]);
  const frameRef = useRef(null);
  const isDraggingRef = useRef(false);
  const prevMouseRef = useRef({ x: 0, y: 0 });
  const rotationRef = useRef({ y: 0.4, x: -0.15 });
  const autoRotateRef = useRef(true);
  const zoomRef = useRef(6);

  const [activeHotspot, setActiveHotspot] = useState(null);
  const [hoveredHotspot, setHoveredHotspot] = useState(null);
  const [hint, setHint] = useState(true);

  // Init Three.js
  useEffect(() => {
    const el = mountRef.current;
    if (!el) return;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0d1530);
    scene.fog = new THREE.FogExp2(0x0d1530, 0.055);
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(45, el.clientWidth / el.clientHeight, 0.1, 100);
    camera.position.set(0, 1.2, zoomRef.current);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(el.clientWidth, el.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    el.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lights
    const ambient = new THREE.AmbientLight(0x223366, 1.2);
    scene.add(ambient);
    const keyLight = new THREE.DirectionalLight(0xffffff, 2.5);
    keyLight.position.set(-5, 8, 6);
    scene.add(keyLight);
    const fillLight = new THREE.DirectionalLight(0x4466aa, 0.8);
    fillLight.position.set(6, 2, -4);
    scene.add(fillLight);
    const rimLight = new THREE.DirectionalLight(0xd90429, 0.5);
    rimLight.position.set(0, -2, -6);
    scene.add(rimLight);

    // Grid lines (airstrip aesthetic)
    const gridHelper = new THREE.GridHelper(20, 20, 0x1a2a55, 0x111d3a);
    gridHelper.position.y = -0.57;
    scene.add(gridHelper);

    // Build truck
    const truck = buildTruck(scene);
    truckRef.current = truck;

    // Hotspots
    hotspotMeshesRef.current = buildHotspotMeshes(scene, HOTSPOTS);

    // Animate
    let t = 0;
    const animate = () => {
      frameRef.current = requestAnimationFrame(animate);
      t += 0.016;

      if (autoRotateRef.current && !isDraggingRef.current) {
        rotationRef.current.y += 0.003;
      }

      truck.rotation.y = rotationRef.current.y;
      truck.rotation.x = rotationRef.current.x;

      // Pulse rings
      hotspotMeshesRef.current.forEach(({ ring }, i) => {
        const pulse = Math.sin(t * 2 + i * 1.2) * 0.5 + 0.5;
        ring.material.opacity = 0.15 + pulse * 0.45;
        const s = 1 + pulse * 0.5;
        ring.scale.set(s, s, s);
        ring.lookAt(camera.position);
        // Sync ring to mesh world position
        const worldPos = new THREE.Vector3();
        hotspotMeshesRef.current[i].mesh.getWorldPosition(worldPos);
        ring.position.copy(worldPos);
      });

      // Sync hotspot meshes to truck rotation
      hotspotMeshesRef.current.forEach(({ mesh }, i) => {
        const hs = HOTSPOTS[i];
        const local = hs.position.clone();
        truck.localToWorld(local);
        mesh.position.copy(local);
      });

      renderer.render(scene, camera);
    };
    animate();

    // Resize
    const onResize = () => {
      if (!el) return;
      camera.aspect = el.clientWidth / el.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(el.clientWidth, el.clientHeight);
    };
    window.addEventListener('resize', onResize);

    return () => {
      window.removeEventListener('resize', onResize);
      cancelAnimationFrame(frameRef.current);
      renderer.dispose();
      if (el.contains(renderer.domElement)) el.removeChild(renderer.domElement);
    };
  }, []);

  // Mouse / touch drag rotation
  const onPointerDown = useCallback((e) => {
    isDraggingRef.current = true;
    autoRotateRef.current = false;
    setHint(false);
    const x = e.touches ? e.touches[0].clientX : e.clientX;
    const y = e.touches ? e.touches[0].clientY : e.clientY;
    prevMouseRef.current = { x, y };
  }, []);

  const onPointerMove = useCallback((e) => {
    if (!isDraggingRef.current) return;
    const x = e.touches ? e.touches[0].clientX : e.clientX;
    const y = e.touches ? e.touches[0].clientY : e.clientY;
    const dx = x - prevMouseRef.current.x;
    const dy = y - prevMouseRef.current.y;
    rotationRef.current.y += dx * 0.008;
    rotationRef.current.x = Math.max(-0.5, Math.min(0.4, rotationRef.current.x + dy * 0.005));
    prevMouseRef.current = { x, y };
  }, []);

  const onPointerUp = useCallback(() => {
    isDraggingRef.current = false;
  }, []);

  // Click to detect hotspot hits via raycasting
  const onCanvasClick = useCallback((e) => {
    const el = mountRef.current;
    const renderer = rendererRef.current;
    const camera = cameraRef.current;
    if (!el || !renderer || !camera) return;

    const rect = el.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), camera);

    const meshes = hotspotMeshesRef.current.map((h) => h.mesh);
    const hits = raycaster.intersectObjects(meshes);

    if (hits.length > 0) {
      const id = hits[0].object.userData.hotspotId;
      const hs = HOTSPOTS.find((h) => h.id === id);
      setActiveHotspot((prev) => (prev?.id === id ? null : hs));
      autoRotateRef.current = false;
    } else {
      setActiveHotspot(null);
    }
  }, []);

  // Zoom
  const zoom = useCallback((dir) => {
    zoomRef.current = Math.max(3.5, Math.min(10, zoomRef.current + dir));
    if (cameraRef.current) {
      cameraRef.current.position.z = zoomRef.current;
    }
  }, []);

  const resetView = useCallback(() => {
    rotationRef.current = { y: 0.4, x: -0.15 };
    zoomRef.current = 6;
    if (cameraRef.current) cameraRef.current.position.z = 6;
    autoRotateRef.current = true;
    setActiveHotspot(null);
  }, []);

  return (
    <div className="relative w-full rounded-2xl overflow-hidden bg-[#0d1530] shadow-2xl shadow-midnight/40">
      {/* Canvas mount */}
      <div
        ref={mountRef}
        className="w-full h-[480px] cursor-grab active:cursor-grabbing select-none"
        onMouseDown={onPointerDown}
        onMouseMove={onPointerMove}
        onMouseUp={onPointerUp}
        onMouseLeave={onPointerUp}
        onTouchStart={onPointerDown}
        onTouchMove={onPointerMove}
        onTouchEnd={onPointerUp}
        onClick={onCanvasClick}
      />

      {/* Top-left label */}
      <div className="absolute top-4 left-4 flex items-center gap-2">
        <div className="glass-dark rounded-full px-3 py-1.5 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-velocity animate-pulse" />
          <span className="font-mono text-[10px] text-white/60 tracking-wider uppercase">
            3D Interactive Viewer
          </span>
        </div>
      </div>

      {/* Controls */}
      <div className="absolute top-4 right-4 flex flex-col gap-2">
        <button
          onClick={resetView}
          className="w-9 h-9 glass-dark rounded-xl flex items-center justify-center hover:bg-white/10 transition-colors"
          title="Reset view"
        >
          <RotateCcw className="w-4 h-4 text-white/60" />
        </button>
        <button
          onClick={() => zoom(-1)}
          className="w-9 h-9 glass-dark rounded-xl flex items-center justify-center hover:bg-white/10 transition-colors"
          title="Zoom in"
        >
          <ZoomIn className="w-4 h-4 text-white/60" />
        </button>
        <button
          onClick={() => zoom(1)}
          className="w-9 h-9 glass-dark rounded-xl flex items-center justify-center hover:bg-white/10 transition-colors"
          title="Zoom out"
        >
          <ZoomOut className="w-4 h-4 text-white/60" />
        </button>
      </div>

      {/* Drag hint */}
      {hint && (
        <div className="absolute bottom-24 left-1/2 -translate-x-1/2 pointer-events-none">
          <div className="glass-dark rounded-full px-4 py-2 flex items-center gap-2 animate-pulse">
            <span className="text-xs text-white/50">Drag to rotate · Click hotspots to inspect</span>
          </div>
        </div>
      )}

      {/* Hotspot info panel */}
      {activeHotspot && (
        <div className="absolute bottom-4 left-4 right-4 sm:left-auto sm:right-4 sm:w-72">
          <div className="glass-dark rounded-2xl p-5 border border-velocity/20">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-velocity" />
                <h4 className="text-white font-bold text-sm">{activeHotspot.detail.title}</h4>
              </div>
              <button
                onClick={() => setActiveHotspot(null)}
                className="text-white/40 hover:text-white/80 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <ul className="space-y-2">
              {activeHotspot.detail.specs.map((spec) => (
                <li key={spec} className="flex items-center gap-2 text-xs text-white/60">
                  <div className="w-1 h-1 rounded-full bg-velocity shrink-0" />
                  {spec}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* Hotspot legend */}
      <div className="absolute bottom-4 left-4 flex flex-wrap gap-2" style={{ display: activeHotspot ? 'none' : 'flex' }}>
        {HOTSPOTS.map((hs) => (
          <div
            key={hs.id}
            className="glass-dark rounded-full px-2.5 py-1 flex items-center gap-1.5 cursor-pointer hover:bg-white/10 transition-colors"
            onClick={() => {
              setActiveHotspot(hs);
              autoRotateRef.current = false;
            }}
          >
            <div className="w-1.5 h-1.5 rounded-full bg-velocity" />
            <span className="text-[10px] text-white/50 font-mono">{hs.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}