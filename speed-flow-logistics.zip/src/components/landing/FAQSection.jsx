import React from 'react';
import useScrollReveal from '@/hooks/useScrollReveal';
import SectionLabel from './SectionLabel';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQS = [
  {
    q: 'How do I open an account with Speed-Tech UK?',
    a: 'Opening an account is straightforward. Contact our operations team at ops@speedtechuk.com or call 01753 688059. We will guide you through the onboarding process and set up your online booking access.'
  },
  {
    q: 'How does the online booking system work?',
    a: 'Our online portal allows you to book shipments, track deliveries, and manage your logistics operations digitally. Once your account is set up, you will receive login credentials and full access to our Day Book Pro platform.'
  },
  {
    q: 'How can I track my freight?',
    a: 'We provide real-time tracking via our Quartix GPS platform, geofencing alerts, and live shipment notifications. You can monitor your consignment from collection to delivery with full visibility.'
  },
  {
    q: 'What is the Dailies service?',
    a: 'Our Dailies service provides scheduled daily trunking routes between Heathrow and Manchester, offering reliable and cost-effective freight transport on fixed schedules.'
  },
  {
    q: 'Can you handle high-security cargo?',
    a: 'Yes. As a CAA Regulated Agent (GB/RA/00972-01), we operate under strict aviation security protocols with electronic seal systems, GPS tracking, and comprehensive security procedures for high-value and sensitive cargo.'
  },
  {
    q: 'What is the Heathrow to Manchester trunking service?',
    a: 'Our dedicated trunking service connects London Heathrow and Manchester International Airport with regular scheduled and on-demand transport, providing seamless air cargo movement between the UK\'s major air freight hubs.'
  },
  {
    q: 'What does Regulated Agent status mean?',
    a: 'As a CAA Regulated Agent, Speed-Tech UK is authorised to screen and secure cargo for air transport. This means we meet the highest standards of aviation security as mandated by the Civil Aviation Authority.'
  },
  {
    q: 'Are you TAPA accredited?',
    a: 'We operate in accordance with TAPA (Transported Asset Protection Association) standards, implementing robust security measures to protect high-value cargo throughout the supply chain.'
  },
  {
    q: 'Do you support refrigerated cargo?',
    a: 'Yes. Our temperature-controlled fleet is equipped with ADDSECURE remote monitoring systems, ensuring GDP-compliant cold-chain logistics for pharmaceutical, healthcare, and perishable goods.'
  },
];

export default function FAQSection() {
  const [ref, isVisible] = useScrollReveal();

  return (
    <section className="py-24 lg:py-32 bg-white">
      <div
        ref={ref}
        className={`max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <div className="text-center mb-16">
          <SectionLabel label="FAQ" />
          <h2 className="text-4xl lg:text-5xl font-bold text-midnight tracking-tight mb-4">
            Frequently Asked <span className="text-velocity">Questions</span>
          </h2>
        </div>

        <Accordion type="single" collapsible className="space-y-3">
          {FAQS.map((faq, i) => (
            <AccordionItem
              key={i}
              value={`faq-${i}`}
              className="bg-cloud-deck rounded-xl border-none px-6 data-[state=open]:shadow-md transition-shadow"
            >
              <AccordionTrigger className="text-left text-midnight font-semibold hover:text-velocity hover:no-underline py-5 text-base">
                {faq.q}
              </AccordionTrigger>
              <AccordionContent className="text-midnight/60 leading-relaxed pb-5">
                {faq.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}