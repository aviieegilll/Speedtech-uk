import React from 'react';
import useScrollReveal from '@/hooks/useScrollReveal';
import SectionLabel from './SectionLabel';
import {
  Plane, Beaker, Heart, Flag, Package, ShieldAlert, Truck, AlertTriangle
} from 'lucide-react';

const INDUSTRIES = [
  { icon: Plane, label: 'Air Cargo' },
  { icon: Plane, label: 'Aviation' },
  { icon: Beaker, label: 'Pharmaceutical' },
  { icon: Heart, label: 'Healthcare' },
  { icon: Flag, label: 'Motorsport' },
  { icon: Package, label: 'Commercial Freight' },
  { icon: ShieldAlert, label: 'High-Security Logistics' },
  { icon: AlertTriangle, label: 'Dangerous Goods' },
];

export default function IndustriesSection() {
  const [ref, isVisible] = useScrollReveal();

  return (
    <section className="py-20 bg-cloud-deck">
      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <div className="text-center mb-12">
          <SectionLabel label="Industries Served" />
          <h2 className="text-3xl lg:text-4xl font-bold text-midnight tracking-tight">
            Trusted Across <span className="text-velocity">Industries</span>
          </h2>
        </div>

        <div className="flex flex-wrap justify-center gap-4">
          {INDUSTRIES.map((ind, i) => (
            <div
              key={ind.label}
              className={`flex items-center gap-3 bg-white rounded-full px-6 py-3 border border-midnight/5 hover:border-velocity/20 hover:shadow-md transition-all duration-500 group ${
                isVisible ? 'animate-fade-up' : 'opacity-0'
              }`}
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <ind.icon className="w-4 h-4 text-velocity" />
              <span className="text-sm font-medium text-midnight group-hover:text-velocity transition-colors">
                {ind.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}