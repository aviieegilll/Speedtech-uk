import React from 'react';
import useScrollReveal from '@/hooks/useScrollReveal';
import SectionLabel from './SectionLabel';
import { Users, Award, Truck, Globe } from 'lucide-react';

const PILLARS = [
  { icon: Users, title: 'Family-Owned', desc: 'Founded by Baljinder & Jatinder Khosa' },
  { icon: Award, title: 'Est. 2004', desc: '20+ years of logistics excellence' },
  { icon: Truck, title: 'Specialist Fleet', desc: '138+ dedicated vehicles & trailers' },
  { icon: Globe, title: 'Nationwide', desc: 'UK-wide coverage from Heathrow & Manchester' },
];

export default function AboutSection() {
  const [ref, isVisible] = useScrollReveal();

  return (
    <section id="about" className="py-24 lg:py-32 bg-white">
      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <SectionLabel label="About Speed-Tech UK" />
            <h2 className="text-4xl lg:text-5xl font-bold text-midnight leading-tight tracking-tight mb-6">
              Experience Unrivalled
              <br />
              <span className="text-velocity">Air Freight Excellence</span>
            </h2>
            <p className="text-lg text-midnight/60 leading-relaxed mb-6">
              Speed-Tech UK is a Heathrow-based specialist airfreight and logistics 
              company established in 2004. As a family-owned business, we combine deep 
              industry expertise with personal commitment to deliver exceptional logistics 
              solutions across the United Kingdom.
            </p>
            <p className="text-base text-midnight/50 leading-relaxed mb-8">
              From our strategic hubs at London Heathrow and Manchester International 
              Airport, we provide comprehensive air cargo logistics, same-day delivery, 
              aviation support, pharmaceutical transport, dangerous goods handling, 
              and specialist freight solutions — operating 24/7 to meet the demands 
              of time-critical logistics.
            </p>
            <div className="flex items-center gap-4">
              <div className="h-px flex-1 bg-midnight/10" />
              <span className="font-mono text-xs text-midnight/40 tracking-wider uppercase">
                Efficiency in Motion
              </span>
              <div className="h-px flex-1 bg-midnight/10" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-5">
            {PILLARS.map((pillar, i) => (
              <div
                key={pillar.title}
                className={`glass rounded-2xl p-6 hover:shadow-lg hover:shadow-midnight/5 transition-all duration-500 group ${
                  isVisible ? 'animate-fade-up' : 'opacity-0'
                }`}
                style={{ animationDelay: `${i * 150}ms` }}
              >
                <div className="w-12 h-12 rounded-xl bg-velocity/10 flex items-center justify-center mb-4 group-hover:bg-velocity/20 transition-colors">
                  <pillar.icon className="w-6 h-6 text-velocity" />
                </div>
                <h3 className="font-bold text-midnight text-lg mb-1">{pillar.title}</h3>
                <p className="text-sm text-midnight/50 leading-relaxed">{pillar.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}