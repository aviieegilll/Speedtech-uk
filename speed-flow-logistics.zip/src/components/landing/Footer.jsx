import React from 'react';
import { Phone, Mail, MapPin, ArrowUp } from 'lucide-react';

const LINKS = {
  Services: [
    'Same Day Specials', 'Logistics', 'Airport Transfer', 'Backloads',
    'Motorsport Logistics', 'Dangerous Goods', 'Aviation Support – AOG',
    'Pharma & Healthcare', 'Contract Hire'
  ],
  Company: ['About Us', 'Our Fleet', 'Technology', 'Accreditations', 'Locations', 'Contact'],
};

export default function Footer() {
  return (
    <footer className="bg-midnight text-white">
      {/* Velocity line */}
      <div className="h-px w-full bg-gradient-to-r from-transparent via-velocity to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 bg-velocity rounded-lg flex items-center justify-center">
                <span className="text-white font-mono font-bold text-sm">ST</span>
              </div>
              <div className="flex flex-col">
                <span className="text-white font-bold text-lg leading-tight tracking-tight">
                  SPEED-TECH
                </span>
                <span className="text-velocity font-mono text-[10px] tracking-[0.2em] uppercase">
                  United Kingdom
                </span>
              </div>
            </div>
            <p className="text-white/40 text-sm leading-relaxed mb-6">
              Specialist Heathrow-based airfreight and logistics company delivering 
              nationwide precision since 2004.
            </p>
            <div className="space-y-3">
              <a href="tel:01753688059" className="flex items-center gap-2 text-sm text-white/50 hover:text-velocity transition-colors">
                <Phone className="w-4 h-4" /> 01753 688059
              </a>
              <a href="mailto:ops@speedtechuk.com" className="flex items-center gap-2 text-sm text-white/50 hover:text-velocity transition-colors">
                <Mail className="w-4 h-4" /> ops@speedtechuk.com
              </a>
            </div>
          </div>

          {/* Service Links */}
          <div>
            <h4 className="font-bold text-white mb-4 text-sm">Services</h4>
            <ul className="space-y-2">
              {LINKS.Services.map((link) => (
                <li key={link}>
                  <a href="#services" className="text-sm text-white/40 hover:text-velocity transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Links */}
          <div>
            <h4 className="font-bold text-white mb-4 text-sm">Company</h4>
            <ul className="space-y-2">
              {LINKS.Company.map((link) => (
                <li key={link}>
                  <a href={`#${link.toLowerCase().replace(/\s/g, '-')}`} className="text-sm text-white/40 hover:text-velocity transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Locations */}
          <div>
            <h4 className="font-bold text-white mb-4 text-sm">Locations</h4>
            <div className="space-y-4">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-velocity shrink-0 mt-0.5" />
                <p className="text-sm text-white/40">
                  Heathrow Cargo, Horse Shoe Sheds
                </p>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-velocity shrink-0 mt-0.5" />
                <p className="text-sm text-white/40">
                  Manchester International Airport, World Freight Terminal
                </p>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-velocity shrink-0 mt-0.5" />
                <p className="text-sm text-white/40">
                  Skyway 14, Colnbrook, Berkshire SL3 0BQ
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-white/10 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-sm text-white/30">
            © {new Date().getFullYear()} Speed-Tech UK. All rights reserved.
          </div>
          <div className="flex items-center gap-4">
            <span className="font-mono text-[10px] text-white/20 tracking-wider">
              ISO 9001:2015 • CAA GB/RA/00972-01
            </span>
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="w-10 h-10 rounded-full bg-white/5 hover:bg-velocity flex items-center justify-center transition-all duration-300"
            >
              <ArrowUp className="w-4 h-4 text-white/40 hover:text-white" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}