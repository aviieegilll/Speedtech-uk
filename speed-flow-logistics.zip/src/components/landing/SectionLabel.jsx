import React from 'react';

export default function SectionLabel({ label }) {
  return (
    <div className="flex items-center gap-3 mb-6">
      <div className="w-8 h-px bg-velocity" />
      <span className="font-mono text-xs tracking-[0.15em] uppercase text-velocity font-semibold">
        {label}
      </span>
    </div>
  );
}