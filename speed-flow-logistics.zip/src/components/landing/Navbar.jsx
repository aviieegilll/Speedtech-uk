import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion, AnimatePresence } from 'framer-motion';

const NAV_LINKS = [
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Fleet', href: '#fleet' },
  { label: 'Technology', href: '#technology' },
  { label: 'Locations', href: '#locations' },
  { label: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', handler);
    return () => window.removeEventListener('scroll', handler);
  }, []);

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'glass shadow-lg shadow-midnight/5 py-3'
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Logo */}
          <a href="#hero" className="flex items-center gap-2 group">
            <div className="w-9 h-9 bg-velocity rounded-lg flex items-center justify-center">
              <span className="text-white font-mono font-bold text-sm">ST</span>
            </div>
            <div className="flex flex-col">
              <span className="text-midnight font-bold text-lg leading-tight tracking-tight">
                SPEED-TECH
              </span>
              <span className="text-velocity font-mono text-[10px] tracking-[0.2em] uppercase">
                United Kingdom
              </span>
            </div>
          </a>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-8">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm font-medium text-midnight/70 hover:text-velocity transition-colors duration-300 relative group"
              >
                {link.label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-velocity transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </div>

          {/* Desktop CTA */}
          <div className="hidden lg:flex items-center gap-4">
            <a href="tel:01753688059" className="flex items-center gap-2 text-sm text-midnight/70 hover:text-velocity transition-colors">
              <Phone className="w-4 h-4" />
              <span className="font-mono">01753 688059</span>
            </a>
            <a href="#contact">
              <Button className="bg-velocity hover:bg-velocity/90 text-white rounded-full px-6 text-sm gap-2 group">
                Get a Quote
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </a>
          </div>

          {/* Mobile Toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="lg:hidden p-2 text-midnight"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-white pt-20"
          >
            <div className="flex flex-col items-center gap-6 p-8">
              {NAV_LINKS.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="text-2xl font-semibold text-midnight hover:text-velocity transition-colors"
                >
                  {link.label}
                </a>
              ))}
              <div className="h-px w-16 bg-velocity/30 my-2" />
              <a href="tel:01753688059" className="flex items-center gap-2 text-midnight/70">
                <Phone className="w-5 h-5" />
                <span className="font-mono text-lg">01753 688059</span>
              </a>
              <a href="#contact" onClick={() => setMobileOpen(false)}>
                <Button className="bg-velocity hover:bg-velocity/90 text-white rounded-full px-8 py-6 text-lg gap-2">
                  Get a Quote
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}