import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

const PARTNERS = [
  {
    id: 1, name: 'DSV',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/DSV_logo.svg/320px-DSV_logo.svg.png',
    desc: 'Global transport & logistics solutions'
  },
  {
    id: 2, name: 'DHL',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/DHL_logo.svg/320px-DHL_logo.svg.png',
    desc: 'International express delivery'
  },
  {
    id: 3, name: 'Nippon Express',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Nippon_Express_logo.svg/320px-Nippon_Express_logo.svg.png',
    desc: 'Japanese global logistics leader'
  },
  {
    id: 4, name: 'Davies Turner',
    logo: 'https://www.daviesturner.com/wp-content/themes/daviesturner/assets/img/davies-turner-logo.png',
    desc: 'UK freight forwarding specialist'
  },
  {
    id: 5, name: 'Hellmann',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Hellmann_Worldwide_Logistics_logo.svg/320px-Hellmann_Worldwide_Logistics_logo.svg.png',
    desc: 'Worldwide logistics network'
  },
  {
    id: 6, name: 'Woodland Group',
    logo: 'https://www.woodland-group.com/wp-content/uploads/2019/06/woodland-group-logo.png',
    desc: 'Supply chain & logistics solutions'
  },
  {
    id: 7, name: 'SEKO',
    logo: 'https://www.sekologistics.com/us/wp-content/uploads/2020/07/SEKO-Logo-White-Stacked.png',
    desc: 'Omnichannel logistics'
  },
  {
    id: 8, name: 'Geodis',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/97/Geodis_logo.svg/320px-Geodis_logo.svg.png',
    desc: 'European freight leader'
  },
  {
    id: 9, name: 'Yusen Logistics',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Yusen_Logistics_logo.svg/320px-Yusen_Logistics_logo.svg.png',
    desc: 'Air & sea freight specialist'
  },
  {
    id: 10, name: 'Expeditors',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/Expeditors_logo.svg/320px-Expeditors_logo.svg.png',
    desc: 'Global logistics company'
  },
  {
    id: 11, name: 'Kuehne+Nagel',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Kuehne_%2B_Nagel_logo.svg/320px-Kuehne_%2B_Nagel_logo.svg.png',
    desc: 'Sea & air freight leader'
  },
];

// Fallback initials if logo fails to load
function getInitials(name) {
  return name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

function getOrbitPosition(index, total, radius) {
  const angle = (index / total) * 2 * Math.PI - Math.PI / 2;
  return { x: Math.cos(angle) * radius, y: Math.sin(angle) * radius };
}

export default function ContractsNetworkSection() {
  const [expanded, setExpanded] = useState(false);
  const [selected, setSelected] = useState(null);
  const [hovered, setHovered] = useState(null);
  const [isMobile, setIsMobile] = useState(false);
  const [logoErrors, setLogoErrors] = useState({});

  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 640);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  const canvasSize = isMobile ? 300 : 480;
  const center = canvasSize / 2;
  const orbitRadius = isMobile ? 115 : 185;
  const bubbleSize = isMobile ? 52 : 68;
  const centerSize = isMobile ? 90 : 110;

  const handleLogoError = (id) => setLogoErrors(prev => ({ ...prev, [id]: true }));

  return (
    <section className="py-24 lg:py-32 bg-midnight relative overflow-hidden">
      {/* Subtle background dots */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.08) 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }}
      />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">

        {/* ── Header (outside radar) ── */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-1.5 mb-5">
            <span className="w-1.5 h-1.5 rounded-full bg-velocity animate-pulse" />
            <span className="font-mono text-[11px] text-white/50 tracking-widest uppercase">Contract Network</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-white tracking-tight mb-4">
            Global <span className="text-velocity">Partnerships</span>
          </h2>
          <p className="text-base text-white/40 max-w-lg mx-auto leading-relaxed">
            Speed-Tech UK operates within a trusted network of world-class logistics partners.
          </p>
        </div>

        {/* ── Radar canvas ── */}
        <div className="flex flex-col items-center">
          <div
            className="relative"
            style={{ width: canvasSize, height: canvasSize }}
          >
            {/* Radar rings */}
            {[0.28, 0.48, 0.68, 0.88].map((ratio, i) => (
              <motion.div
                key={i}
                className="absolute rounded-full border border-white/5"
                style={{
                  width: canvasSize * ratio,
                  height: canvasSize * ratio,
                  top: center - (canvasSize * ratio) / 2,
                  left: center - (canvasSize * ratio) / 2,
                }}
                animate={{ scale: [1, 1.01, 1], opacity: [0.5, 0.8, 0.5] }}
                transition={{ duration: 4 + i, repeat: Infinity, ease: 'easeInOut', delay: i * 0.8 }}
              />
            ))}

            {/* Radar sweep */}
            <motion.div
              className="absolute rounded-full overflow-hidden"
              style={{ inset: 0 }}
              animate={{ rotate: 360 }}
              transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
            >
              <div
                className="w-full h-full rounded-full"
                style={{
                  background: 'conic-gradient(from 0deg, rgba(217,4,41,0.10) 0deg, transparent 55deg)',
                }}
              />
            </motion.div>

            {/* Crosshair lines */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="absolute w-px h-full bg-white/4" />
              <div className="absolute h-px w-full bg-white/4" />
            </div>

            {/* Connection lines SVG */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
              <AnimatePresence>
                {expanded && PARTNERS.map((p, i) => {
                  const pos = getOrbitPosition(i, PARTNERS.length, orbitRadius);
                  const isActive = hovered === p.id || selected?.id === p.id;
                  return (
                    <motion.line
                      key={p.id}
                      x1={center} y1={center}
                      x2={center + pos.x} y2={center + pos.y}
                      stroke={isActive ? 'rgba(217,4,41,0.7)' : 'rgba(255,255,255,0.1)'}
                      strokeWidth={isActive ? 1.2 : 0.6}
                      strokeDasharray="3 5"
                      initial={{ pathLength: 0, opacity: 0 }}
                      animate={{ pathLength: 1, opacity: 1 }}
                      exit={{ pathLength: 0, opacity: 0 }}
                      transition={{ duration: 0.5, delay: i * 0.04 }}
                    />
                  );
                })}
              </AnimatePresence>
            </svg>

            {/* Partner bubbles */}
            <AnimatePresence>
              {expanded && PARTNERS.map((partner, i) => {
                const pos = getOrbitPosition(i, PARTNERS.length, orbitRadius);
                const isSelected = selected?.id === partner.id;
                const isHovered = hovered === partner.id;

                return (
                  <motion.button
                    key={partner.id}
                    className="absolute flex items-center justify-center rounded-full cursor-pointer focus:outline-none"
                    style={{
                      width: bubbleSize,
                      height: bubbleSize,
                      left: center + pos.x - bubbleSize / 2,
                      top: center + pos.y - bubbleSize / 2,
                      background: isSelected
                        ? 'rgba(217,4,41,0.18)'
                        : 'rgba(255,255,255,0.06)',
                      backdropFilter: 'blur(14px)',
                      border: isSelected
                        ? '1.5px solid rgba(217,4,41,0.5)'
                        : '1px solid rgba(255,255,255,0.13)',
                      boxShadow: isSelected
                        ? '0 0 18px rgba(217,4,41,0.25), 0 4px 20px rgba(0,0,0,0.5)'
                        : isHovered
                        ? '0 0 14px rgba(255,255,255,0.08), 0 4px 16px rgba(0,0,0,0.4)'
                        : '0 2px 12px rgba(0,0,0,0.35)',
                    }}
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{
                      scale: 1,
                      opacity: 1,
                      y: [0, -3, 0],
                    }}
                    exit={{ scale: 0, opacity: 0, transition: { duration: 0.2 } }}
                    transition={{
                      scale: { type: 'spring', stiffness: 280, damping: 22, delay: i * 0.05 },
                      opacity: { duration: 0.3, delay: i * 0.05 },
                      y: { duration: 3.5 + i * 0.25, repeat: Infinity, ease: 'easeInOut', delay: i * 0.18 },
                    }}
                    whileHover={{ scale: 1.15 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={(e) => { e.stopPropagation(); setSelected(isSelected ? null : partner); }}
                    onHoverStart={() => setHovered(partner.id)}
                    onHoverEnd={() => setHovered(null)}
                  >
                    {logoErrors[partner.id] ? (
                      <span className="text-white font-bold" style={{ fontSize: isMobile ? 9 : 10 }}>
                        {getInitials(partner.name)}
                      </span>
                    ) : (
                      <img
                        src={partner.logo}
                        alt={partner.name}
                        className="w-3/4 h-3/4 object-contain"
                        style={{ filter: 'brightness(0) invert(1)', opacity: 0.85 }}
                        onError={() => handleLogoError(partner.id)}
                      />
                    )}
                  </motion.button>
                );
              })}
            </AnimatePresence>

            {/* Center STL button */}
            <div className="absolute inset-0 flex items-center justify-center z-20">
              <motion.button
                className="relative flex items-center justify-center rounded-full cursor-pointer focus:outline-none"
                style={{ width: centerSize, height: centerSize }}
                onClick={() => { setExpanded(e => !e); setSelected(null); }}
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
              >
                {/* Pulse rings (idle only) */}
                {!expanded && [1, 2].map(r => (
                  <motion.div
                    key={r}
                    className="absolute rounded-full border border-velocity/25"
                    style={{ inset: -(r * 14) }}
                    animate={{ scale: [1, 1.12, 1], opacity: [0.35, 0, 0.35] }}
                    transition={{ duration: 2.5, delay: r * 0.6, repeat: Infinity, ease: 'easeInOut' }}
                  />
                ))}

                {/* Burst ring on expand */}
                <AnimatePresence>
                  {expanded && (
                    <motion.div
                      className="absolute inset-0 rounded-full border border-velocity/50"
                      initial={{ scale: 1, opacity: 1 }}
                      animate={{ scale: 3.5, opacity: 0 }}
                      exit={{}}
                      transition={{ duration: 0.65, ease: 'easeOut' }}
                    />
                  )}
                </AnimatePresence>

                {/* Button face */}
                <div
                  className="w-full h-full rounded-full flex flex-col items-center justify-center z-10 relative"
                  style={{
                    background: 'linear-gradient(145deg, #D90429 0%, #9b0120 100%)',
                    boxShadow: '0 0 28px rgba(217,4,41,0.45), 0 0 56px rgba(217,4,41,0.15), inset 0 1px 0 rgba(255,255,255,0.15)',
                    border: '1px solid rgba(255,255,255,0.18)',
                  }}
                >
                  <span className="font-bold text-white tracking-widest leading-tight" style={{ fontSize: isMobile ? 8 : 10 }}>STL</span>
                  <span className="font-bold text-white tracking-widest leading-tight" style={{ fontSize: isMobile ? 8 : 10 }}>CONTRACTS</span>
                  <div className="w-8 h-px bg-white/20 my-1" />
                  <span className="text-white/55 font-mono" style={{ fontSize: isMobile ? 6 : 7 }}>
                    {expanded ? 'CLOSE' : 'CLICK TO EXPAND'}
                  </span>
                </div>
              </motion.button>
            </div>
          </div>

          {/* Partner detail card */}
          <AnimatePresence>
            {selected && (
              <motion.div
                initial={{ opacity: 0, y: 16, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 8, scale: 0.97 }}
                transition={{ type: 'spring', stiffness: 320, damping: 28 }}
                className="mt-8 w-full max-w-xs"
              >
                <div
                  className="rounded-2xl p-5 relative"
                  style={{
                    background: 'rgba(255,255,255,0.05)',
                    backdropFilter: 'blur(20px)',
                    border: '1px solid rgba(255,255,255,0.1)',
                    boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
                  }}
                >
                  <button
                    onClick={() => setSelected(null)}
                    className="absolute top-3 right-3 text-white/25 hover:text-white/70 transition-colors"
                  >
                    <X size={14} />
                  </button>
                  <div className="flex items-center gap-3 mb-3">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center overflow-hidden"
                      style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.12)' }}
                    >
                      {logoErrors[selected.id] ? (
                        <span className="text-white font-bold text-xs">{getInitials(selected.name)}</span>
                      ) : (
                        <img
                          src={selected.logo}
                          alt={selected.name}
                          className="w-8 h-8 object-contain"
                          style={{ filter: 'brightness(0) invert(1)', opacity: 0.85 }}
                          onError={() => handleLogoError(selected.id)}
                        />
                      )}
                    </div>
                    <div>
                      <h4 className="text-white font-bold text-base leading-tight">{selected.name}</h4>
                      <span className="font-mono text-[10px] text-velocity/70 uppercase tracking-wider">Active Contract</span>
                    </div>
                  </div>
                  <p className="text-white/50 text-sm leading-relaxed">{selected.desc}</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Hint */}
          <AnimatePresence>
            {expanded && !selected && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ delay: 0.5 }}
                className="mt-6 text-white/25 text-[11px] font-mono tracking-widest text-center"
              >
                TAP ANY PARTNER TO VIEW DETAILS
              </motion.p>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}