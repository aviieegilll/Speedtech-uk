import React from 'react';
import useScrollReveal from '@/hooks/useScrollReveal';
import SectionLabel from './SectionLabel';
import { ShieldCheck, Award, FileCheck, Beaker, Plane, CheckCircle2 } from 'lucide-react';

const ACCREDITATIONS = [
  { icon: Award, title: 'ISO 9001:2015', desc: 'Quality Management System certified by UKAS', tag: 'CERTIFIED' },
  { icon: Plane, title: 'CAA Regulated Agent', desc: 'GB/RA/00972-01 — Aviation security compliance', tag: 'AVIATION' },
  { icon: ShieldCheck, title: 'ADR Compliance', desc: 'Dangerous goods transportation certified', tag: 'SAFETY' },
  { icon: Beaker, title: 'GDP Compliance', desc: 'Pharmaceutical logistics certified', tag: 'PHARMA' },
  { icon: FileCheck, title: 'Aviation Security', desc: 'Full aviation security compliance', tag: 'SECURITY' },
  { icon: CheckCircle2, title: 'UKAS Certification', desc: 'United Kingdom Accreditation Service', tag: 'QUALITY' },
];

export default function AccreditationsSection() {
  const [ref, isVisible] = useScrollReveal();

  return (
    <section className="py-24 lg:py-32 bg-cloud-deck">
      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <div className="text-center max-w-3xl mx-auto mb-16">
          <SectionLabel label="Compliance & Accreditations" />
          <h2 className="text-4xl lg:text-5xl font-bold text-midnight tracking-tight mb-4">
            High Quality <span className="text-velocity">Standards</span>
          </h2>
          <p className="text-lg text-midnight/50">
            Industry-leading certifications and accreditations ensuring the highest 
            standards of safety, quality, and regulatory compliance.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {ACCREDITATIONS.map((acc, i) => (
            <div
              key={acc.title}
              className={`bg-white rounded-2xl p-7 group hover:shadow-lg hover:shadow-midnight/5 transition-all duration-500 border border-midnight/5 hover:border-velocity/20 ${
                isVisible ? 'animate-fade-up' : 'opacity-0'
              }`}
              style={{ animationDelay: `${i * 100}ms` }}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-velocity/8 flex items-center justify-center group-hover:bg-velocity transition-all duration-500">
                  <acc.icon className="w-6 h-6 text-velocity group-hover:text-white transition-colors" />
                </div>
                <span className="font-mono text-[10px] tracking-wider text-velocity/60 bg-velocity/5 px-2 py-1 rounded-full">
                  {acc.tag}
                </span>
              </div>
              <h3 className="text-lg font-bold text-midnight mb-2">{acc.title}</h3>
              <p className="text-sm text-midnight/50 leading-relaxed">{acc.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}