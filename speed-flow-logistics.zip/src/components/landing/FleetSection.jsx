import React from 'react';
import useScrollReveal from '@/hooks/useScrollReveal';
import SectionLabel from './SectionLabel';
import { Truck, Container, Gauge, Snowflake, Box } from 'lucide-react';

const FLEET_DATA = [
  { label: 'Mercedes Vans', detail: 'Dedicated van fleet', icon: Truck },
  { label: '23 Rigid Vehicles', detail: 'Heavy-duty logistics', icon: Box },
  { label: '45 Tractor Units', detail: 'Volvo & Scania units', icon: Truck },
  { label: '70 Trailers', detail: 'Q6 & Q7 rollerbeds', icon: Container },
  { label: 'Hydraroll Systems', detail: 'Rollerbed technology', icon: Gauge },
  { label: 'Temp-Controlled', detail: 'Cold-chain capable', icon: Snowflake },
];

const SPECS = [
  'Air-ride suspension systems',
  'ULD transportation capability',
  'Electronic seal systems',
  'GPS-tracked fleet operations',
  'Temperature monitoring',
  'Heavy-duty cargo handling',
];

export default function FleetSection() {
  const [ref, isVisible] = useScrollReveal();

  return (
    <section id="fleet" className="py-24 lg:py-32 bg-white overflow-hidden">
      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <SectionLabel label="Fleet Showcase" />
            <h2 className="text-4xl lg:text-5xl font-bold text-midnight tracking-tight mb-4">
              Purpose-Built for
              <br />
              <span className="text-velocity">Precision Logistics</span>
            </h2>
            <p className="text-lg text-midnight/50 leading-relaxed mb-10">
              Our fleet of 138+ specialist vehicles includes Volvo and Scania tractor 
              units, rollerbed trailers, temperature-controlled units, and dedicated 
              Mercedes vans — all equipped with cutting-edge tracking and safety systems.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-10">
              {FLEET_DATA.map((item, i) => (
                <div
                  key={item.label}
                  className={`bg-cloud-deck rounded-xl p-4 group hover:bg-midnight transition-all duration-500 ${
                    isVisible ? 'animate-fade-up' : 'opacity-0'
                  }`}
                  style={{ animationDelay: `${i * 100}ms` }}
                >
                  <item.icon className="w-5 h-5 text-velocity mb-2" />
                  <p className="text-sm font-bold text-midnight group-hover:text-white transition-colors">
                    {item.label}
                  </p>
                  <p className="text-xs text-midnight/40 group-hover:text-white/50 transition-colors">
                    {item.detail}
                  </p>
                </div>
              ))}
            </div>

            <div className="space-y-3">
              <p className="font-mono text-xs tracking-wider uppercase text-midnight/30 mb-3">
                Technical Specifications
              </p>
              <div className="grid grid-cols-2 gap-2">
                {SPECS.map((spec) => (
                  <div key={spec} className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-velocity" />
                    <span className="text-sm text-midnight/60">{spec}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="relative rounded-2xl overflow-hidden bg-cloud-deck">
            <img
              src="https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?w=800&q=80"
              alt="Speed-Tech UK fleet"
              className="w-full h-80 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-midnight/60 via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <div className="glass-dark rounded-xl p-4 flex items-center justify-between">
                <div>
                  <p className="text-white/40 text-xs font-mono uppercase tracking-wider mb-0.5">Total Fleet</p>
                  <p className="text-2xl font-bold text-white">138+</p>
                  <p className="text-white/50 text-sm">Specialist vehicles & trailers</p>
                </div>
                <div className="w-12 h-12 rounded-full bg-velocity/20 flex items-center justify-center">
                  <Truck className="w-6 h-6 text-velocity" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}