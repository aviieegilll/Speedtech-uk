import React, { useState } from 'react';
import useScrollReveal from '@/hooks/useScrollReveal';
import SectionLabel from './SectionLabel';
import {
  Zap, Package, Plane, RotateCw, Flag, AlertTriangle,
  Wrench, Thermometer, FileText, ArrowRight
} from 'lucide-react';

const SERVICES = [
  {
    icon: Zap, title: 'Same Day Specials',
    desc: 'Dedicated same-day urgent delivery solutions for import and export consignments using dedicated vehicles with real-time POD/POC tracking, rapid response transport, and time-critical logistics support.',
    tag: 'URGENT'
  },
  {
    icon: Package, title: 'Logistics',
    desc: 'Full UK-wide logistics and air freight transport services connecting Heathrow, Manchester, and nationwide operations with precision planning and specialist project handling.',
    tag: 'NATIONWIDE'
  },
  {
    icon: Plane, title: 'Airport Transfer Service',
    desc: 'Specialist air cargo ground movement between airline sheds, airport bonds, and logistics facilities with strict aviation security procedures and regulated cargo handling.',
    tag: 'AVIATION'
  },
  {
    icon: RotateCw, title: 'Backloads',
    desc: 'Cost-efficient backload logistics solutions designed to optimise transport capacity, reduce costs, improve efficiency, and support sustainable logistics operations.',
    tag: 'EFFICIENT'
  },
  {
    icon: Flag, title: 'Motorsport Logistics',
    desc: 'Specialist motorsport logistics support including race car transportation, high-value cargo movement, event logistics, and time-sensitive motorsport freight operations.',
    tag: 'SPECIALIST'
  },
  {
    icon: AlertTriangle, title: 'Dangerous Goods',
    desc: 'ADR-compliant dangerous goods transportation with trained DGSA-certified staff, specialist handling procedures, emergency preparedness systems, and strict regulatory compliance.',
    tag: 'ADR'
  },
  {
    icon: Wrench, title: 'Aviation Support – AOG',
    desc: 'Aircraft On Ground emergency logistics support providing rapid-response transport for critical aviation components, aircraft parts, aerospace freight, and emergency aviation operations.',
    tag: 'EMERGENCY'
  },
  {
    icon: Thermometer, title: 'Pharma & Healthcare',
    desc: 'GDP-compliant pharmaceutical and healthcare logistics with cold-chain transport, temperature-controlled vehicles, ADDSECURE temperature monitoring, and secure medical freight handling.',
    tag: 'GDP'
  },
  {
    icon: FileText, title: 'Contract Hire',
    desc: 'Flexible contract hire logistics services providing dedicated fleet support, scalable transport solutions, and tailored long-term logistics partnerships.',
    tag: 'FLEXIBLE'
  },
];

export default function ServicesSection() {
  const [ref, isVisible] = useScrollReveal();
  const [activeIndex, setActiveIndex] = useState(null);

  return (
    <section id="services" className="py-24 lg:py-32 bg-cloud-deck">
      <div
        ref={ref}
        className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <div className="text-center max-w-3xl mx-auto mb-16">
          <SectionLabel label="Our Services" />
          <h2 className="text-4xl lg:text-5xl font-bold text-midnight tracking-tight mb-4">
            Innovate. Automate. <span className="text-velocity">Elevate.</span>
          </h2>
          <p className="text-lg text-midnight/50">
            Comprehensive logistics solutions tailored for every industry — from 
            time-critical air cargo to temperature-controlled pharmaceutical transport.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {SERVICES.map((svc, i) => (
            <div
              key={svc.title}
              className={`group relative bg-white rounded-2xl p-7 cursor-pointer transition-all duration-500 hover:shadow-xl hover:shadow-midnight/5 hover:-translate-y-1 border border-transparent hover:border-velocity/10 ${
                isVisible ? 'animate-fade-up' : 'opacity-0'
              }`}
              style={{ animationDelay: `${i * 80}ms` }}
              onMouseEnter={() => setActiveIndex(i)}
              onMouseLeave={() => setActiveIndex(null)}
            >
              <div className="flex items-start justify-between mb-5">
                <div className="w-12 h-12 rounded-xl bg-velocity/8 flex items-center justify-center group-hover:bg-velocity group-hover:shadow-lg group-hover:shadow-velocity/20 transition-all duration-500">
                  <svc.icon className="w-6 h-6 text-velocity group-hover:text-white transition-colors duration-500" />
                </div>
                <span className="font-mono text-[10px] tracking-wider text-midnight/30 bg-midnight/5 px-2 py-1 rounded-full">
                  {svc.tag}
                </span>
              </div>

              <h3 className="text-lg font-bold text-midnight mb-3 group-hover:text-velocity transition-colors">
                {svc.title}
              </h3>

              <p className={`text-sm text-midnight/50 leading-relaxed transition-all duration-500 ${
                activeIndex === i ? 'max-h-40 opacity-100' : 'max-h-12 overflow-hidden'
              }`}>
                {svc.desc}
              </p>

              <div className="mt-4 flex items-center gap-2 text-velocity text-sm font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                Learn More <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}