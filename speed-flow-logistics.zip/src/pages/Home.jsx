import React from 'react';
import Navbar from '@/components/landing/Navbar';
import HeroSection from '@/components/landing/HeroSection';
import AboutSection from '@/components/landing/AboutSection';
import ServicesSection from '@/components/landing/ServicesSection';
import FleetSection from '@/components/landing/FleetSection';
import TechnologySection from '@/components/landing/TechnologySection';
import AccreditationsSection from '@/components/landing/AccreditationsSection';
import WhyChooseSection from '@/components/landing/WhyChooseSection';
import IndustriesSection from '@/components/landing/IndustriesSection';
import LocationsSection from '@/components/landing/LocationsSection';
import FAQSection from '@/components/landing/FAQSection';
import ContractsNetworkSection from '@/components/landing/ContractsNetworkSection';
import ContactSection from '@/components/landing/ContactSection';
import Footer from '@/components/landing/Footer';

const HERO_IMAGE = 'https://media.base44.com/images/public/6a1550cdf6b050f37764562e/628df14a4_generated_449aa454.png';
const FLEET_IMAGE = 'https://media.base44.com/images/public/6a1550cdf6b050f37764562e/2d56cfce5_generated_3c8c1ee6.png';

export default function Home() {
  return (
    <div className="min-h-screen bg-white font-inter">
      <Navbar />
      <HeroSection heroImage={HERO_IMAGE} />
      <AboutSection />
      <ServicesSection />
      <FleetSection />
      <TechnologySection />
      <WhyChooseSection />
      <AccreditationsSection />
      <IndustriesSection />
      <LocationsSection />
      <ContractsNetworkSection />
      <FAQSection />
      <ContactSection />
      <Footer />
    </div>
  );
}